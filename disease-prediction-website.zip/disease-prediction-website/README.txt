DISEASE PREDICTION SYSTEM  (Diabetes + Heart Disease)
=====================================================
Pure HTML + CSS + JavaScript website. No Python, no install, no server needed.

FILES
  index.html      main page
  css/style.css   design (light + dark mode, mobile friendly)
  js/model.js     trained Random Forest + Naive Bayes models (data)
  js/engine.js    prediction logic (runs in the browser)
  js/app.js       form, validation, result, history

OPEN IN VS CODE
  File > Open Folder > select "disease-prediction-website"
  Double-click index.html in your file manager to run it, or use the "Live Server" extension
  (right-click index.html > Open with Live Server).

UPLOAD (FREE HOSTING) - upload the whole folder, index.html must stay at the top level
  Option 1 (easiest): Netlify Drop - open app.netlify.com/drop and drag the folder in.
  Option 2: GitHub Pages - push the folder contents to a GitHub repo, then
            Settings > Pages > Deploy from branch (main, / root).
  Option 3: Vercel - import the folder / repo, framework "Other", no build command.

Educational project - predictions are not a medical diagnosis.

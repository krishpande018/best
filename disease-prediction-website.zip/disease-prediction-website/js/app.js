// User interface: tabs, form, validation, result display, history.
const $=id=>document.getElementById(id);let cur="diabetes";
const KEYS=Object.keys(MODEL);
const store={get(){try{return JSON.parse(localStorage.getItem("dps_h")||"[]")}catch(e){return[]}},set(v){try{localStorage.setItem("dps_h",JSON.stringify(v))}catch(e){}}};
function tabs(){$("tabs").innerHTML=KEYS.map(k=>`<button class="tab ${k==cur?"on":""}" data-k="${k}">${MODEL[k].icon} ${MODEL[k].title}</button>`).join("")+`<button class="tab ${cur=="perf"?"on":""}" data-k="perf">📊 Model performance</button>`;
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{cur=b.dataset.k;render();});}
function render(){tabs();const perf=cur=="perf";$("pred").classList.toggle("h",perf);$("perf").classList.toggle("h",!perf);if(perf)return perfPage();
const D=MODEL[cur];$("out").classList.add("h");$("ph").classList.remove("h");
$("form").innerHTML=`<h2>${D.icon} ${D.title} risk check</h2><p class="m">${D.dataset}</p><div class="f">`+D.spec.map(f=>`<label><b>${f.label}${f.optional?" <i>(optional)</i>":""}</b>`+(f.type=="select"?`<select name="${f.name}">${Object.entries(f.options).map(([v,t])=>`<option value="${v}" ${v==f.default?"selected":""}>${t}</option>`).join("")}</select>`:`<input type="number" name="${f.name}" min="${f.min}" max="${f.max}" step="${f.step}" value="${f.default??""}">`)+(f.help?`<small>${f.help}</small>`:"")+`<span class="e" id="e_${f.name}"></span></label>`).join("")+`</div><div class="act"><button class="p" type="submit">Predict</button><button type="reset">Reset</button></div>`;
$("form").onreset=()=>{$("out").classList.add("h");$("ph").classList.remove("h");};hist();}
$("form").addEventListener("submit",e=>{e.preventDefault();const D=MODEL[cur],fd=new FormData($("form")),x=[];let bad=false;
D.spec.forEach(f=>{const el=$("e_"+f.name);el.textContent="";const raw=String(fd.get(f.name)??"").trim();
if(raw===""){if(f.optional){x.push(NaN);return;}el.textContent="Required";bad=true;x.push(NaN);return;}
const v=Number(raw);if(!Number.isFinite(v)||(f.type=="number"&&(v<f.min||v>f.max))){el.textContent=f.type=="number"?`Must be ${f.min} - ${f.max}`:"Invalid";bad=true;}x.push(v);});
if(bad)return;const p=probRF(cur,x),r=level(cur,p),pc=Math.round(p*100),c={High:"high",Moderate:"mod",Low:"low"}[r];
$("ph").classList.add("h");$("out").classList.remove("h");$("pc").textContent=pc+"%";$("fl").style.width=pc+"%";$("fl").className="fl "+c;$("mk").style.left=D.thr*100+"%";
$("bd").textContent=r+" risk";$("bd").className="bd "+c;$("ex").textContent=`Random Forest probability. Marker = screening threshold (${Math.round(D.thr*100)}%).`;
$("nb").textContent=`Naïve Bayes estimate: ${Math.round(probNB(cur,x)*100)}%`;
const fa=explain(cur,x);$("fa").innerHTML=fa.length?fa.map(a=>`<li><span>${a.f}</span><b class="${a.d>0?"up":"dn"}">${a.d>0?"▲ +":"▼ "}${a.d} pts</b></li>`).join(""):`<li class="m">Values are close to typical - no dominant factor.</li>`;
const h=store.get();h.unshift({t:new Date().toLocaleString(),d:D.title,p:pc,r});store.set(h.slice(0,8));hist();});
function hist(){const h=store.get();$("hist").innerHTML=h.length?`<div class="tw"><table><tr><th>Time</th><th>Disease</th><th>Probability</th><th>Risk</th></tr>${h.map(a=>`<tr><td>${a.t}</td><td>${a.d}</td><td>${a.p}%</td><td>${a.r}</td></tr>`).join("")}</table></div>`:"None yet.";$("clr").classList.toggle("h",!h.length);}
$("clr").onclick=()=>{store.set([]);hist();};
function perfPage(){$("perf").innerHTML=KEYS.map(k=>{const D=MODEL[k],a=D.met.rf,b=D.met.nb,t=D.met.rfthr,mx=D.imp[0][1];
const row=(n,m)=>`<tr><td>${n}</td><td>${m.accuracy}</td><td>${m.precision}</td><td>${m.recall}</td><td>${m.f1}</td><td>${m.roc_auc}</td></tr>`;
return `<div class="c"><h2>${D.icon} ${D.title}</h2><p class="m">${D.dataset} &middot; ${D.rows} rows &middot; ${Math.round(D.pos*100)}% positive &middot; held-out 20% test set</p>
<div class="tw"><table><tr><th>Model</th><th>Accuracy</th><th>Precision</th><th>Recall</th><th>F1</th><th>ROC-AUC</th></tr>${row("Random Forest",a)}${row("Naïve Bayes",b)}</table></div>
<h3>Random Forest confusion matrix at screening threshold ${D.thr}</h3><div class="tw"><table style="max-width:420px"><tr><th></th><th>Pred. healthy</th><th>Pred. disease</th></tr><tr><th>Actually healthy</th><td>${t.tn}</td><td>${t.fp}</td></tr><tr><th>Actually disease</th><td class="up">${t.fn}</td><td>${t.tp}</td></tr></table></div>
<h3>Most important features</h3>${D.imp.slice(0,7).map(([n,v])=>`<div class="br"><span>${n}</span><div><u style="width:${v/mx*100}%"></u></div><span>${(v*100).toFixed(1)}%</span></div>`).join("")}</div>`;}).join("");}
render();

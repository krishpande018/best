// Prediction engine: runs the trained Random Forest / Naive Bayes directly in the browser.
function imp(D,x){return x.map((v,i)=>Number.isFinite(v)?v:D.med[i]);}
function treeP(T,x){let n=0;while(T.f[n]>=0){n=x[T.f[n]]<=T.t[n]?T.l[n]:T.r[n];}return T.v[n];}
function probRF(k,x){const D=MODEL[k];x=imp(D,x);return D.rf.reduce((s,T)=>s+treeP(T,x),0)/D.rf.length;}
function probNB(k,x){const D=MODEL[k];x=imp(D,x);const ll=[0,1].map(c=>Math.log(D.nb.prior[c])+x.reduce((s,v,i)=>{const z=(v-D.sc.m[i])/D.sc.s[i],mu=D.nb.mu[c][i],va=D.nb.var[c][i];return s-0.5*Math.log(2*Math.PI*va)-(z-mu)**2/(2*va);},0));const mx=Math.max(...ll),e=ll.map(v=>Math.exp(v-mx));return e[1]/(e[0]+e[1]);}
function level(k,p){const t=MODEL[k].thr;return p>=t?"High":p>=0.6*t?"Moderate":"Low";}
function explain(k,x){const D=MODEL[k],p=probRF(k,x),o=[];D.names.forEach((n,i)=>{if(!Number.isFinite(x[i]))return;const a=x.slice();a[i]=D.med[i];const d=(p-probRF(k,a))*100;if(Math.abs(d)>=0.5)o.push({f:D.spec[i].label,d:Math.round(d*10)/10});});return o.sort((a,b)=>Math.abs(b.d)-Math.abs(a.d)).slice(0,5);}
